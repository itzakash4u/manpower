

<?php $__env->startSection('extra-styles'); ?>
<style>
    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
    }
    li {
        display:inline;
        margin-left: 40px;
        font-size:16px;
        font-weight:bolder;
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if(Session::has('success')): ?> <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div> <?php endif; ?>
 
 <?php if($errors->any()): ?>
     <div class="alert alert-danger">
         <ul>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li><?php echo e($error); ?></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
     </div>
 <?php endif; ?>

<?php if(Session::has('success')): ?> <div class="alert alert-success"><?php echo e(Session::get('success')); ?> <a href="<?php echo e(url('user-login')); ?>" class="signin-btn">Sign In</a> <?php endif; ?></div>
                    <form method="post" action="<?php echo e(url('submit-register')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>User Type</label>
                            <select class="form-control" name="type" required>
                                <option value="">--SELECT--</option>
                                <option value="employer">Employer</option>
                                <option value="employee">Employee</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" class="form-control" name="phone" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <textarea class="form-control" name="addr" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>State</label>
                            <input type="text" class="form-control" name="state" required>
                        </div>
                        <div class="form-group">
                            <label>Aadhar Number</label>
                            <input type="text" class="form-control" name="aadhar" required>
                        </div>
                        <div class="form-group">
                            <label>Profile Picture</label>
                            <input type="file" class="form-control" name="profile_pic" required>
                        </div>
                        <div class="form-group">
                            <label>Aadhar Image</label>
                            <input type="file" class="form-control" name="aadhar_img" required>
                        </div>
                        <div class="form-group">
                            <label>Account Holder Name</label>
                            <input type="text" class="form-control" name="acc_holder" required>
                        </div>
                        <div class="form-group">
                            <label>Account No</label>
                            <input type="text" class="form-control" name="account_no" required>
                        </div>
                        <div class="form-group">
                            <label>IFSC</label>
                            <input type="text" class="form-control" name="ifsc" required>
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary" value="Register">
                        </div>
                    </form>
      

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mpn.front.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\manpower-app\resources\views/mpn/front/register.blade.php ENDPATH**/ ?>