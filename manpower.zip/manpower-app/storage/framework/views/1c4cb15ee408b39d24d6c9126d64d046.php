<?php echo $__env->make('mpn.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('mpn.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

        <?php echo $__env->yieldContent('main-content'); ?>


        </div> <!-- container -->

    </div> <!-- content -->

    <?php echo $__env->make('mpn.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\manpower-app\resources\views/mpn/main.blade.php ENDPATH**/ ?>