<?php $__env->startSection('content'); ?>

        <!-- Page Title Start -->
        <section class="page-title title-bg10">
            <div class="d-table">
                <div class="d-table-cell">
                    <h2>Account</h2>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>Change Password</li>
                    </ul>
                </div>
            </div>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </section>
        <!-- Page Title End -->

        <!-- Account Area Start -->
        <?php if(Session::has('success')): ?> <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div> <?php endif; ?>
        <?php if(Session::has('danger')): ?> <div class="alert alert-danger"><?php echo e(Session::get('danger')); ?></div> <?php endif; ?>
        <section class="account-section ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="account-information">
                            <div class="profile-thumb">
                                <!--<img src="assets/img/account.jpg" alt="account holder image">-->
                                <img src="<?php echo e(asset('media/profile/'.$user->profile_image)); ?>" alt="account holder image">
                                <h3><?php echo e($user->name); ?></h3>
                                <!--<p>Web Developer</p>-->
                            </div>

                            <ul>
                                <li>
                                    <a href="view-profile/<?php echo e($user->id); ?>" class="active">
                                        <i class='bx bx-user'></i>
                                        My Profile
                                    </a>
                                </li>
                                <!--<li>-->
                                <!--    <a href="resume.html" target="_blank">-->
                                <!--        <i class='bx bxs-file-doc'></i>-->
                                <!--        My Resume-->
                                <!--    </a>-->
                                <!--</li>-->
                                <!--<li>-->
                                <!--    <a href="#">-->
                                <!--        <i class='bx bx-briefcase'></i>-->
                                <!--        Applied Job-->
                                <!--    </a>-->
                                <!--</li>-->
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-8">
                        <div class="account-details">
                            <h3>Change Password</h3>
                            <form method="post" class="basic-info" action="<?php echo e(url('submit-change-password')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Old Password</label>
                                            <input type="text" class="form-control" name="old">
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" name="password" id="pass" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Retype Password</label>
                                            <input type="password" name="repass" id="repass" class="form-control">
                                            <span id="err" style="color:red"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <button type="submit" class="account-btn">Change Password</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Account Area End -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-scripts'); ?>


<script>
    $(document).ready(function() {
        $('#repass').keyup(function(e) {
            if($('#pass').val()!=$('#repass').val()) {
                $('#submit').prop('disabled', true)
                $('#err').html('Password not matched!')
            }else {
                $('#submit').prop('disabled', false)
                $('#err').html('')
            }
        })
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('mpn.front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rendement/public_html/mpn/manpower-app/resources/views/mpn/front/change-password.blade.php ENDPATH**/ ?>