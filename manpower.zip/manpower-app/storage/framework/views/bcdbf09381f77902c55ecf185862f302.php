<?php $__env->startSection('content'); ?>


        <!-- Page Title Start -->
        <section class="page-title title-bg1">
            <div class="d-table">
                <div class="d-table-cell">
                    <h2>About Us</h2>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>About Us</li>
                    </ul>
                </div>
            </div>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </section>
        <!-- Page Title End -->

        <!-- About Section Start -->
        <section class="about-section ptb-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-text">
                            <div class="section-title">
                                <h2>How We Started</h2>
                            </div>

                            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>

                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="<?php echo e(asset('front/img/about.jpg')); ?>" alt="about image">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Section End -->

		<!-- Way To Use Section Start -->
		<section class="use-section pt-100 pb-70">
			<div class="container">
				<div class="section-title text-center">
					<h2>Easiest Way To Use</h2>
				</div>

				<div class="row">
					<div class="col-lg-4 col-sm-6">
						<div class="use-text">
							<span>1</span>
							<i class='flaticon-website'></i>
							<h3>Browse Job</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
						</div>
					</div>

					<div class="col-lg-4 col-sm-6">
						<div class="use-text">
							<span>2</span>
							<i class='flaticon-recruitment'></i>
							<h3>Find Your Vaccancy</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
						</div>
					</div>

					<div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0">
						<div class="use-text">
							<span>3</span>
							<i class='flaticon-login'></i>
							<h3>Submit Resume</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!-- Way To Use Section End -->
        
        <!-- Why Choose Section Start -->
        <section class="why-choose-two pt-100 pb-70">
            <div class="container">
                <div class="section-title text-center">
                    <h2>Why You Choose Us Among Other Job Site?</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus</p>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-sm-6">
                        <div class="choose-card">
                            <i class="flaticon-resume"></i>
                            <h3>Advertise Job</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore   </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6">
                        <div class="choose-card">
                            <i class="flaticon-recruitment"></i>
                            <h3>Recruiter Profiles</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore   </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0">
                        <div class="choose-card">
                            <i class="flaticon-employee"></i>
                            <h3>Find Your Dream Job</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore   </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Why Choose Section End -->

        <!-- Grow Business Section Start -->
        <div class="grow-business pb-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7">
                        <div class="grow-text">
                            <div class="section-title">
                                <h2>Grow Your Business Faster With Premium Advertising</h2>
                            </div>

                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.
                            </p>

                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Consectetur adipiscing elit.
                            </p>

                            <div class="theme-btn">
                                <a href="#" class="default-btn">Checkout More</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5">
                        <div class="grow-img">
                            <img src="<?php echo e(asset('front/img/grow-img.jpg')); ?>" alt="grow image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Grow Business Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mpn.front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rendement/public_html/mpn/manpower-app/resources/views/mpn/front/about.blade.php ENDPATH**/ ?>