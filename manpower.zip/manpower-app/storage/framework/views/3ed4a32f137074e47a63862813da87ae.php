<?php $__env->startSection('content'); ?>


        <!-- Page Title Start -->
        <section class="page-title title-bg11">
            <div class="d-table">
                <div class="d-table-cell">
                    <h2>ID Card</h2>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>ID Card</li>
                    </ul>
                </div>
            </div>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </section>
        <!-- Page Title End -->

        <!-- Resume Area Start -->
        <section class="resume-section ptb-100">
            <div class="container">
                <div class="resume-area">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="resume-thumb-area text-center">
                                <img src="<?php echo e(asset('media/profile/'.$user->profile_image)); ?>" alt="account image">
                                <h3><?php echo e($user->name); ?></h3>
                                <!--<p>Web Developer</p>-->
                                
                                <!--<div class="social-links">-->
                                <!--    <a href="#" target="-blank">-->
                                <!--        <i class="bx bxl-facebook"></i>-->
                                <!--    </a>-->
                                <!--    <a href="#" target="-blank">-->
                                <!--        <i class="bx bxl-twitter"></i>-->
                                <!--    </a>-->
                                <!--    <a href="#" target="-blank">-->
                                <!--        <i class="bx bxl-github"></i>-->
                                <!--    </a>-->
                                <!--    <a href="#" target="-blank">-->
                                <!--        <i class="bx bxl-linkedin"></i>-->
                                <!--    </a>-->
                                <!--</div>-->
                            </div>
                        </div>

                        <div class="col-md-12">
                            <!--<div class="resume-content about-text">-->
                            <!--    <h3>-->
                            <!--        <i class='bx bx-user-circle'></i>-->
                            <!--        About Me-->
                            <!--    </h3>-->
                            <!--    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>-->
                            <!--</div>-->

                            <div class="resume-content basic-info-text">
                                <h3>
                                    <i class='bx bx-book-alt'></i>
                                    Basic Info
                                </h3>
                                <ul>
                                    <li>
                                        <span>Aadhar Number:</span>
                                        <?php echo e($user->aadhar_no); ?>

                                    </li>
                                    <li>
                                        <span>Category:</span>
                                        <?php $cat=\App\Models\Category::find($user->category_id); ?>
                                        <?php echo e($cat->category_name); ?>

                                    </li>
                                    <li>
                                        <span>Mobile:</span>
                                        <?php echo e($user->phone); ?>

                                    </li>
                                    <!--<li>-->
                                    <!--    <span>Gender:</span>-->
                                    <!--    Male-->
                                    <!--</li>-->
                                    <!--<li>-->
                                    <!--    <span>Status:</span>-->
                                    <!--    Full Time-->
                                    <!--</li>-->
                                    <li>
                                        <span>Employee Type:</span>
                                        <?php echo e(strtoupper($user->worker_type)); ?>

                                    </li>
                                </ul>
                            </div>

                            <!--<div class="resume-content education-text">-->
                            <!--    <h3>-->
                            <!--        <i class='bx bx-book-reader'></i>-->
                            <!--        Education Background-->
                            <!--    </h3>-->

                            <!--    <div class="education-info">-->
                            <!--        <span>2014-2018</span>-->
                            <!--        <h5>Diploma in Computer engineering</h5>-->
                            <!--        <h4>Columbia University</h4>-->
                            <!--        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>-->
                            <!--    </div>-->
                            <!--    <div class="education-info">-->
                            <!--        <span>2010-2014</span>-->
                            <!--        <h5>Bachelor in Computer Science</h5>-->
                            <!--        <h4>Oxford university, UK</h4>-->
                            <!--        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>-->
                            <!--    </div>-->
                            <!--    <div class="education-info">-->
                            <!--        <span>2008-2010</span>-->
                            <!--        <h5>Higher School certificate</h5>-->
                            <!--        <h4>Stanton College, USA</h4>-->
                            <!--        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>-->
                            <!--    </div>-->
                            <!--</div>-->

                            <!--<div class="resume-content  experience-text">-->
                            <!--    <h3>-->
                            <!--        <i class='bx bx-briefcase'></i>-->
                            <!--        Work Expericence-->
                            <!--    </h3>-->

                            <!--    <div class="experience-info">-->
                            <!--        <span>2016-2018</span>-->
                            <!--        <h5>Junior Web Developer</h5>-->
                            <!--        <h4>Stack LTD Company</h4>-->
                            <!--        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>-->
                            <!--    </div>-->
                            <!--    <div class="experience-info">-->
                            <!--        <span>2018-2021</span>-->
                            <!--        <h5>Full Stack Developer</h5>-->
                            <!--        <h4>Sanders IT</h4>-->
                            <!--        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>-->
                            <!--    </div>-->
                            <!--</div>-->

                            <!--<div class="resume-content skill">-->
                            <!--    <h3>-->
                            <!--        <i class='bx bx-check-shield'></i>-->
                            <!--        Skills-->
                            <!--    </h3>-->
                            <!--    <span>HTMl</span>-->
                            <!--    <div class="progress">-->
                            <!--        <div class="progress-bar bg-success" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>-->
                            <!--    </div>-->

                            <!--    <span>JS</span>-->
                            <!--    <div class="progress">-->
                            <!--        <div class="progress-bar bg-info" role="progressbar" style="width: 90%" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100">90%</div>-->
                            <!--    </div>-->

                            <!--    <span>PHP</span>-->
                            <!--    <div class="progress">-->
                            <!--        <div class="progress-bar bg-warning" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">85%</div>-->
                            <!--    </div>-->

                            <!--    <span>SQL</span>-->
                            <!--    <div class="progress">-->
                            <!--        <div class="progress-bar bg-danger" role="progressbar" style="width: 95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100">95%</div>-->
                            <!--    </div>-->
                            <!--</div>-->

                            <!--<div class="theme-btn">-->
                            <!--    <a href="#" class="default-btn">-->
                            <!--        Download-->
                            <!--        <i class='bx bx-download bx-fade-down' ></i>-->
                            <!--    </a>-->
                            <!--</div>-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Resume Area End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mpn.front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rendement/public_html/mpn/manpower-app/resources/views/mpn/front/id-card.blade.php ENDPATH**/ ?>