

<?php $__env->startSection('extra-styles'); ?>
        <!-- DataTables -->
        <link href="<?php echo e(asset('ui/plugins/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('ui/plugins/datatables/buttons.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('ui/plugins/datatables/fixedHeader.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('ui/plugins/datatables/responsive.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('ui/plugins/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('ui/plugins/datatables/scroller.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>


                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-header-title">
                                    <h4 class="pull-left page-title">Profile</h4>
                                    <ol class="breadcrumb pull-right">
                                        <li><a href="#"><?php echo e(strtoupper(Auth::user()->role)); ?></a></li>
                                        <li class="active">Profile</li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>

<div class="row">
                            <div class="col-md-12">
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                                <?php if(Session::has('success')): ?>
                                <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                                <?php endif; ?>
                                <?php if(Session::has('danger')): ?>
                                <div class="alert alert-danger"><?php echo e(Session::get('danger')); ?></div>
                                <?php endif; ?>
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Profile</h3>
                                    </div>
                                    <div class="panel-body">
                                        <form method="post" action="<?php echo e(url('/update-profile')); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Name</label>
                                                    <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" placeholder="" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Email</label>
                                                    <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" placeholder="" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Phone</label>
                                                    <input type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>" placeholder="" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Address</label>
                                                    <textarea name="address" class="form-control" required><?php echo e($user->address); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">State</label>
                                                    <select class="form-control" name="state" required>
                                                        <option value="West Bengal">West Bengal</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Account Holder Name</label>
                                                    <input type="text" name="acc_holder" class="form-control" value="<?php echo e($user->ac_holder_name); ?>" placeholder="" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Account No</label>
                                                    <input type="text" name="ac_no" class="form-control" value="<?php echo e($user->ac_number); ?>" placeholder="" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">IFSC Code</label>
                                                    <input type="text" name="ifsc" class="form-control" value="<?php echo e($user->ifsc); ?>" placeholder="" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Profile Picture</label>
                                                    <input type="file" name="pic" class="form-control">
                                                </div>
                                                <div class="form-group" <?php if(empty($user->profile_image)): ?> style="display:none" <?php endif; ?>>
                                                    <img src="<?php echo e(asset('media/profile/'.$user->profile_image)); ?>" width="150" height="140">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12" style="float:right">
                                                <input type="submit" class="btn btn-primary" value="Update">
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div> <!-- End Row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
        <!-- Datatables-->
        <script src="<?php echo e(asset('ui/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/buttons.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.fixedHeader.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.keyTable.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/responsive.bootstrap.min.js')); ?>"></script>
        <script src="{[asset('ui/plugins/datatables/dataTables.scroller.min.js')}}"></script>

        <!-- Datatable init js -->
        <script src="<?php echo e(asset('ui/pages/datatables.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-scripts'); ?>
<script>
    function removeJob(id) {
        if(confirm("Are you sure to delete?")) {
            window.location="remove-job/"+id;
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mpn.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\manpower-app\resources\views/mpn/profile.blade.php ENDPATH**/ ?>