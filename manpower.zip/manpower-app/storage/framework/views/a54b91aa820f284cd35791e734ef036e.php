<?php $__env->startSection('content'); ?>

        <!-- Banner Section Start -->
        <div class="banner-style-three">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <?php if(Session::has('success')): ?> <?php echo e(Session::get('success')); ?> <?php endif; ?>
                        <div class="banner-text">
                            <h1>Find Top Jobs</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <div class="theme-btn">
                                <a href="#" class="default-btn active">Upload your CV</a>
                                <a href="contact.html" class="default-btn">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Banner Section End -->

        <!-- Find Section Start -->
        <div class="find-section pb-100">
            <div class="container">
                <form class="find-form" method="post" action="job-search-result">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group">
                                <input type="text" name="title" class="form-control" id="exampleInputEmail1" placeholder="Job Title or Keyword">
                                <i class="bx bx-search-alt"></i>
                            </div>
                        </div>
    
                        <div class="col-lg-3">
                            <div class="form-group">
                                <input type="text" name="location" class="form-control" id="exampleInputEmail2" placeholder="Location">
                                <i class="bx bx-location-plus"></i>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <select class="category" name="category">
                                <option data-display="Category">Category</option>
                                <?php if($cats): ?>
                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                <!--<option value="2">Graphics Design</option>-->
                                <!--<option value="4">Data Entry</option>-->
                                <!--<option value="5">Visual Editor</option>-->
                                <!--<option value="6">Office Assistant</option>-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
    
                        <div class="col-lg-3">
                            <button type="submit" class="find-btn">
                                Find A Job
                                <i class='bx bx-search'></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Find Section End -->

        <!-- Job Category Section Start -->
        <div class="category-style-two pb-70"> 
            <div class="container">
                <div class="section-title text-center">
                    <h2>Popular Jobs Category</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus</p>
                </div>

                <div class="row">
                    <?php if($cats): ?>
                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $job_count=\App\Models\Job::where('cat_id', $cat->id)->count(); ?>
                    <div class="col-lg-3 col-sm-6">
                        <a href="job-list.html">
                            <div class="category-item">
                                <i class="flaticon-wrench-and-screwdriver-in-cross"></i>
                                <h3><!--Construction--><?php echo e($cat->category_name); ?></h3>
                                <p><?php echo e($job_count); ?> new Job</p>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <!--<div class="col-lg-3 col-sm-6">-->
                    <!--    <a href="job-list.html">-->
                    <!--        <div class="category-item">-->
                    <!--            <i class="flaticon-accounting"></i>-->
                    <!--            <h3>Finance</h3>-->
                    <!--            <p>8 new Job</p>-->
                    <!--        </div>-->
                    <!--    </a>                  -->
                    <!--</div>-->

                    <!--<div class="col-lg-3 col-sm-6">-->
                    <!--    <a href="job-list.html">-->
                    <!--        <div class="category-item">-->
                    <!--            <i class="flaticon-heart"></i>-->
                    <!--            <h3>Healthcare</h3>-->
                    <!--            <p>9 new Job</p>-->
                    <!--        </div>-->
                    <!--    </a>-->
                    <!--</div>-->

                    <!--<div class="col-lg-3 col-sm-6">-->
                    <!--    <a href="job-list.html">-->
                    <!--        <div class="category-item">-->
                    <!--            <i class="flaticon-computer-1"></i>-->
                    <!--            <h3>Graphic Design</h3>-->
                    <!--            <p>6 new Job</p>-->
                    <!--        </div>-->
                    <!--    </a>-->
                    <!--</div>-->

                    <!--<div class="col-lg-3 col-sm-6">-->
                    <!--    <a href="job-list.html">-->
                    <!--        <div class="category-item">-->
                    <!--            <i class="flaticon-research"></i>-->
                    <!--            <h3>Banking Jobs</h3>-->
                    <!--            <p>5 new Job</p>-->
                    <!--        </div>-->
                    <!--    </a>-->
                    <!--</div>-->

                    <!--<div class="col-lg-3 col-sm-6">-->
                    <!--    <a href="job-list.html">-->
                    <!--        <div class="category-item">-->
                    <!--            <i class="flaticon-worker"></i>-->
                    <!--            <h3>Automotive</h3>-->
                    <!--            <p>12 new Job</p>-->
                    <!--        </div>-->
                    <!--    </a>-->
                    <!--</div>-->

                    <!--<div class="col-lg-3 col-sm-6">-->
                    <!--    <a href="job-list.html">-->
                    <!--        <div class="category-item">-->
                    <!--            <i class="flaticon-graduation-cap"></i>-->
                    <!--            <h3>Education</h3>-->
                    <!--            <p>15 new Job</p>-->
                    <!--        </div>-->
                    <!--    </a>-->
                    <!--</div>-->

                    <!--<div class="col-lg-3 col-sm-6">-->
                    <!--    <a href="job-list.html">-->
                    <!--        <div class="category-item">-->
                    <!--            <i class="flaticon-computer"></i>-->
                    <!--            <h3>Data Analysis</h3>-->
                    <!--            <p>5 new Job</p>-->
                    <!--        </div>-->
                    <!--    </a>-->
                    <!--</div>-->
                </div>
            </div>
        </div>
        <!-- Job Category Section End -->

        <!-- Why Choose Section Start -->
        <section class="why-choose">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-7 p-0">
                        <div class="why-choose-text pt-100 pb-70">
                            <div class="section-title text-center">
                                <h2>Why You Choose Jovie?</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolorei.</p>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="media">
                                        <i class="flaticon-group align-self-center mr-3"></i>
                                        <div class="media-body">
                                            <h5 class="mt-0">Best Talented People</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="media">
                                        <i class="flaticon-research align-self-center mr-3"></i>
                                        <div class="media-body">
                                            <h5 class="mt-0">Easy To Find Canditate</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="media">
                                        <i class="flaticon-discussion align-self-center mr-3"></i>
                                        <div class="media-body">
                                            <h5 class="mt-0">Easy To Communicate</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="media">
                                        <i class="flaticon-recruitment align-self-center mr-3"></i>
                                        <div class="media-body">
                                            <h5 class="mt-0">Global Recruitment Option</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row counter-area">
                                <div class="col-md-3 col-6">
                                        <div class="counter-text">
                                        <h2><span>127</span></h2>
                                        <p>Job Posted</p>
                                    </div>
                                </div>

                                <div class="col-md-3 col-6">
                                    <div class="counter-text">
                                        <h2><span>137</span></h2>
                                        <p>Job Filed</p>
                                    </div>
                                </div>

                                <div class="col-md-3 col-6">
                                    <div class="counter-text">
                                        <h2><span>180</span></h2>
                                        <p>Company</p>
                                    </div>
                                </div>

                                <div class="col-md-3 col-6">
                                    <div class="counter-text">
                                        <h2><span>144</span></h2>
                                        <p>Members</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 p-0">
                        <div class="why-choose-img">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Why Choose Section End -->
        
        <!--== Start Work Process Area Wrapper ==-->
        <section class="work-process-area">
            <div class="container" data-aos="fade-down">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title text-center">
                            <h2>How It Work?</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus</p>
                        </div>                    
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="working-process-content-wrap">
                            <div class="working-col">
                                <!--== Start Work Process ==-->
                                <div class="working-process-item">
                                    <div class="icon-box">
                                        <div class="inner">
                                            <img class="icon-img" src="assets/img/icons/w1.png" alt="Image-HasTech">
                                            <img class="icon-hover" src="assets/img/icons/w1-hover.png" alt="Image-HasTech">
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title">Create an Account</h4>
                                        <p class="desc">It is long established fact reader distracted readable content</p>
                                    </div>
                                    <div class="shape-arrow-icon">
                                        <img class="shape-icon" src="assets/img/icons/right-arrow.png" alt="Image-HasTech">
                                        <img class="shape-icon-hover" src="assets/img/icons/right-arrow2.png" alt="Image-HasTech">
                                    </div>
                                </div>
                                <!--== End Work Process ==-->
                            </div>
                            <div class="working-col">
                                <!--== Start Work Process ==-->
                                <div class="working-process-item">
                                    <div class="icon-box">
                                        <div class="inner">
                                            <img class="icon-img" src="assets/img/icons/w2.png" alt="Image-HasTech">
                                            <img class="icon-hover" src="assets/img/icons/w2-hover.png" alt="Image-HasTech">
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title">CV/Resume</h4>
                                        <p class="desc">It is long established fact reader distracted readable content</p>
                                    </div>
                                    <div class="shape-arrow-icon">
                                        <img class="shape-icon" src="assets/img/icons/right-arrow.png" alt="Image-HasTech">
                                        <img class="shape-icon-hover" src="assets/img/icons/right-arrow2.png" alt="Image-HasTech">
                                    </div>
                                </div>
                                <!--== End Work Process ==-->
                            </div>
                            <div class="working-col">
                                <!--== Start Work Process ==-->
                                <div class="working-process-item">
                                    <div class="icon-box">
                                        <div class="inner">
                                            <img class="icon-img" src="assets/img/icons/w3.png" alt="Image-HasTech">
                                            <img class="icon-hover" src="assets/img/icons/w3-hover.png" alt="Image-HasTech">
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title">Find Your Job</h4>
                                        <p class="desc">It is long established fact reader distracted readable content</p>
                                    </div>
                                    <div class="shape-arrow-icon">
                                        <img class="shape-icon" src="assets/img/icons/right-arrow.png" alt="Image-HasTech">
                                        <img class="shape-icon-hover" src="assets/img/icons/right-arrow2.png" alt="Image-HasTech">
                                    </div>
                                </div>
                                <!--== End Work Process ==-->
                            </div>
                            <div class="working-col">
                            <!--== Start Work Process ==-->
                                <div class="working-process-item">
                                    <div class="icon-box">
                                        <div class="inner">
                                            <img class="icon-img" src="assets/img/icons/w4.png" alt="Image-HasTech">
                                            <img class="icon-hover" src="assets/img/icons/w4-hover.png" alt="Image-HasTech">
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h4 class="title">Save & Apply</h4>
                                        <p class="desc">It is long established fact reader distracted readable content</p>
                                    </div>
                                    <div class="shape-arrow-icon d-none">
                                        <img class="shape-icon" src="assets/img/icons/right-arrow.png" alt="Image-HasTech">
                                        <img class="shape-icon-hover" src="assets/img/icons/right-arrow2.png" alt="Image-HasTech">
                                    </div>
                                </div>
                                <!--== End Work Process ==-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--== End Work Process Area Wrapper ==-->

        <!-- Job Section End -->   
        <section class="job-style-two pt-100 pb-70">
            <div class="container">
                <div class="section-title text-center">
                    <h2>Jobs You May Be Interested In</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida</p>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="job-card-two">
                            <div class="row align-items-center">
                                <div class="col-md-1">
                                    <div class="company-logo">
                                        <a href="job-details.html">
                                            <img src="assets/img/company-logo/1.png" alt="logo">
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="job-info">
                                        <h3>
                                            <a href="job-details.html">Web Designer, Graphic Designer, UI/UX Designer </a>
                                        </h3>
                                        <ul>                                          
                                            <li>
                                                <i class='bx bx-briefcase' ></i>
                                                Graphics Designer
                                            </li>
                                            <li>
                                                <i class='bx bx-briefcase' ></i>
                                                $35000-$38000
                                            </li>
                                            <li>
                                                <i class='bx bx-location-plus'></i>
                                                Wellesley Rd, London
                                            </li>
                                            <li>
                                                <i class='bx bx-stopwatch' ></i>
                                                9 days ago
                                            </li>
                                        </ul>

                                        <span>Full Time</span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="theme-btn text-end">
                                        <a href="job-details.html" class="default-btn">
                                            Browse Job
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="job-card-two">
                            <div class="row align-items-center">
                                <div class="col-md-1">
                                    <div class="company-logo">
                                        <a href="job-details.html">     
                                            <img src="assets/img/company-logo/1.png" alt="logo">
                                        </a> 
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="job-info">
                                        <h3>
                                            <a href="job-details.html">Website Developer & Software Developer</a>
                                        </h3>
                                        <ul>                                          
                                            <li>
                                                <i class='bx bx-briefcase' ></i>
                                                Web Developer
                                            </li>
                                            <li>
                                                <i class='bx bx-briefcase' ></i>
                                                $3000-$8000
                                            </li>
                                            <li>
                                                <i class='bx bx-location-plus'></i>
                                                Garden Road, UK
                                            </li>
                                            <li>
                                                <i class='bx bx-stopwatch' ></i>
                                                5 days ago
                                            </li>
                                        </ul>

                                        <span>Full Time</span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="theme-btn text-end">
                                        <a href="job-details.html" class="default-btn">
                                            Browse Job
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="job-card-two">
                            <div class="row align-items-center">
                                <div class="col-md-1">
                                    <div class="company-logo">
                                        <a href="job-details.html">
                                            <img src="assets/img/company-logo/1.png" alt="logo">
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="job-info">
                                        <h3>
                                            <a href="job-details.html">Application Developer & Web Designer</a>
                                        </h3>
                                        <ul>                                          
                                            <li>
                                                <i class='bx bx-briefcase'></i>
                                                App Developer
                                            </li>
                                            <li>
                                                <i class='bx bx-briefcase'></i>
                                                $3000-$4000
                                            </li>
                                            <li>
                                                <i class='bx bx-location-plus'></i>
                                                State City, USA
                                            </li>
                                            <li>
                                                <i class='bx bx-stopwatch' ></i>
                                                8 days ago
                                            </li>
                                        </ul>

                                        <span>Part-Time</span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="theme-btn text-end">
                                        <a href="job-details.html" class="default-btn">
                                            Browse Job
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="job-card-two">
                            <div class="row align-items-center">
                                <div class="col-md-1">
                                    <div class="company-logo">
                                        <a href="job-details.html">
                                            <img src="assets/img/company-logo/1.png" alt="logo">
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="job-info">
                                        <h3>
                                            <a href="job-details.html">Frontend & Backend Developer</a>
                                        </h3>
                                        <ul>                                          
                                            <li>
                                                <i class='bx bx-briefcase' ></i>
                                                Web Developer
                                            </li>
                                            <li>
                                                <i class='bx bx-briefcase' ></i>
                                                $5000-$8000
                                            </li>
                                            <li>
                                                <i class='bx bx-location-plus'></i>
                                                Drive Post NY 676
                                            </li>
                                            <li>
                                                <i class='bx bx-stopwatch' ></i>
                                                1 days ago
                                            </li>
                                        </ul>

                                        <span>Full Time</span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="theme-btn text-end">
                                        <a href="job-details.html" class="default-btn">
                                            Browse Job
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Job Section End -->

        <!-- Testimonial Section Start -->
        <div class="testimonial-style-two testimonial-style-three pt-100 pb-100">
            <div class="container">
                <div class="section-title text-center">
                    <h2>What Client’s Say About Us</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.</p>
                </div>

                <div class="row">
                    <div class="testimonial-slider-two owl-carousel owl-theme">
                        <div class="testimonial-items">
                            <div class="testimonial-text">
                                <i class='flaticon-left-quotes-sign'></i>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do mod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
                            </div>

                            <div class="testimonial-info-text">
                                <img src="assets/img/client-1.png" alt="client image">
                                <h3>Alisa Meair</h3>
                                <p>CEO of  Company</p>
                            </div>
                        </div>

                        <div class="testimonial-items">
                            <div class="testimonial-text">
                                <i class='flaticon-left-quotes-sign'></i>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do mod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
                            </div>

                            <div class="testimonial-info-text">
                                <img src="assets/img/client-2.png" alt="client image">
                                <h3>Adam Smith</h3>
                                <p>Web Developer</p>
                            </div>
                        </div>

                        <div class="testimonial-items">
                            <div class="testimonial-text">
                                <i class='flaticon-left-quotes-sign'></i>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do mod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.</p>
                            </div>

                            <div class="testimonial-info-text">
                                <img src="assets/img/client-1.png" alt="client image">
                                <h3>John Doe</h3>
                                <p>Graphics Designer</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Testimonial Section End --> 

        <!-- Subscribe Section Start -->
        <section class="subscribe-section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="section-title">
                            <h2>Get New Job Notifications</h2>
                            <p>Subscribe & get all related jobs notification</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <form class="newsletter-form" data-toggle="validator">
                            <input type="email" class="form-control" placeholder="Enter your email" name="EMAIL" required autocomplete="off">
    
                            <button class="default-btn sub-btn" type="submit">
                                Subscribe
                            </button>
    
                            <div id="validator-newsletter" class="form-result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- Subscribe Section End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mpn.front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rendement/public_html/mpn/manpower-app/resources/views/mpn/front/home-main.blade.php ENDPATH**/ ?>