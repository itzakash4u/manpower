

<?php $__env->startSection('extra-styles'); ?>
        <!-- DataTables -->
        <link href="<?php echo e(asset('ui/plugins/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('ui/plugins/datatables/buttons.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('ui/plugins/datatables/fixedHeader.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('ui/plugins/datatables/responsive.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('ui/plugins/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('ui/plugins/datatables/scroller.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>


                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-header-title">
                                    <h4 class="pull-left page-title">Category</h4>
                                    <ol class="breadcrumb pull-right">
                                        <li><a href="#">Admin</a></li>
                                        <li class="active">Category</li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>

<div class="row">
    <div class="col-md-12" style="float:right">
        <button class="btn btn-success btn-sm" style="float:right" data-toggle="modal" data-target="#addCategory">Add Category</button>
    </div>
</div>
<br/>

<div class="row">
                            <div class="col-md-12">
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                                <?php if(Session::has('success')): ?>
                                <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                                <?php endif; ?>
                                <?php if(Session::has('danger')): ?>
                                <div class="alert alert-danger"><?php echo e(Session::get('danger')); ?></div>
                                <?php endif; ?>
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Category</h3>
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <table id="datatable" class="table table-striped table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Category</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <?php $sl=0; ?>
                                                       <?php if($cats): ?>
                                                       <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       <?php $sl++; ?>
                                                       <tr>
                                                        <td><?php echo e($sl); ?></td>
                                                        <td><?php echo e($cat->category_name); ?></td>
                                                        <td>
                                                            <a href="javascript:void(0)" data-toggle="modal" data-target="#editCategory<?php echo e($cat->id); ?>"><i class="fa fa-edit"></i></a>
                                                            <a href="javascript:void(0)" onclick="removeCategory(<?php echo e($cat->id); ?>)"><i class="fa fa-trash"></i></a>
                                                        </td>
                                                       </tr>

                                                       
                        <div class="modal fade" id="editCategory<?php echo e($cat->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="post" action="<?php echo e(url('/submit-edit-category')); ?>">
                                        <?php echo csrf_field(); ?>
                                    <div class="modal-header">
                                        <h3 class="modal-title">Edit Category</h3>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="cat_id" value="<?php echo e($cat->id); ?>">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Category Name</label>
                                            <input type="text" class="form-control" name="category" id="" value="<?php echo e($cat->category_name); ?>" placeholder="Enter Category Name">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-dark waves-effect waves-light">Save</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                       <?php endif; ?>
                                                    <tbody>
                                                    </tbody>
                                                </table>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div> <!-- End Row -->

                        <div class="modal fade" id="addCategory">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="post" action="<?php echo e(url('/submit-category')); ?>">
                                        <?php echo csrf_field(); ?>
                                    <div class="modal-header">
                                        <h3 class="modal-title">Add Category</h3>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Category Name</label>
                                            <input type="text" class="form-control" name="category" id="exampleInputPassword1" placeholder="Enter Category Name" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-dark waves-effect waves-light">Save</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-scripts'); ?>
        <!-- Datatables-->
        <script src="<?php echo e(asset('ui/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/buttons.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.fixedHeader.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.keyTable.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/plugins/datatables/responsive.bootstrap.min.js')); ?>"></script>
        <script src="{[asset('ui/plugins/datatables/dataTables.scroller.min.js')}}"></script>

        <!-- Datatable init js -->
        <script src="<?php echo e(asset('ui/pages/datatables.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-scripts'); ?>
<script>
    function removeCategory(id) {
        if(confirm("Are you sure to delete?")) {
            window.location="remove-category/"+id;
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mpn.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rendement/public_html/mpn/manpower-app/resources/views/mpn/add-category.blade.php ENDPATH**/ ?>