




<?php $__env->startSection('content'); ?>

<section class="page-title title-bg13">
    <h2 class="text-center">Sign Up</h2>
    <div class="lines">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
</section>
<div class="container">
    <?php if(Session::has('success')): ?> <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div> <?php endif; ?>
 
 <?php if($errors->any()): ?>
     <div class="alert alert-danger">
         <ul>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li><?php echo e($error); ?></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
     </div>
 <?php endif; ?>

<?php if(Session::has('success')): ?> 
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?> <a href="<?php echo e(url('user-login')); ?>" class="signin-btn">Sign In</a> <?php endif; ?></div>
    <section class="account-login-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-7 col-xl-6">
                    <div class="login-register-form-wrap">
                        <div class="login-register-form">
                            <div class="signin-section ptb-100">
                                <form method="post" action="<?php echo e(url('submit-register')); ?>" enctype="multipart/form-data" class="signin-form find-form">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label>Category</label>
                                        <select class="form-control" name="category" id="category" required>
                                            <option value="">--SELECT--</option>
                                            <?php if($cats): ?>
                                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>User Type</label>
                                        <select class="form-control" name="type" id="type" required>
                                            <option value="">--SELECT--</option>
                                            <option value="employer">Employer</option>
                                            <option value="employee">Employee</option>
                                        </select>
                                    </div>
                                    <div class="form-group" id="emptype" style="display:none">
                                        <label>Employee Type</label>
                                        <select class="form-control" name="gp" id="gp">
                                            <option value="">--SELECT--</option>
                                            <option value="individual">Indivisual</option>
                                            <option value="group">Group</option>
                                        </select>
                                    </div>
                                    
                                    <div class="container" id="group-box" style="display:none">
                                        <div class="element" id="div_1">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control" name="gpname[]" id="gpname">
                                                <label>Phone</label>
                                                <input type="text" class="form-control" name="gpphone[]" id="gpphone">
                                            </div>
                                        </div>
                                        <button type="button" id="add-gp" class="btn btn-primary btn-sm">Add New Member</button>
                                    </div><br/>
                                    
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="text" class="form-control" name="name" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" class="form-control" name="email" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="text" class="form-control" name="phone" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" class="form-control" name="password" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Address</label>
                                        <textarea class="form-control" name="addr" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>State</label>
                                        <input type="text" class="form-control" name="state" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Aadhar Number</label>
                                        <input type="text" class="form-control" name="aadhar">
                                    </div>
                                    <div class="form-group">
                                        <label>Profile Picture</label>
                                        <input type="file" class="form-control" name="profile_pic" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Aadhar Image</label>
                                        <input type="file" class="form-control" name="aadhar_img">
                                    </div>
                                    <div class="form-group">
                                        <label>Account Holder Name</label>
                                        <input type="text" class="form-control" name="acc_holder" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Account No</label>
                                        <input type="text" class="form-control" name="account_no" required>
                                    </div>
                                    <div class="form-group">
                                        <label>IFSC</label>
                                        <input type="text" class="form-control" name="ifsc" required>
                                    </div>
                                    <!--<div class="form-group">-->
                                    <!--    <input type="submit" class="btn btn-primary" value="Register">-->
                                    <!--</div>-->
                                    <div class="signup-btn text-center">
                                        <button type="submit" class="find-btn">Sign Up</button>
                                    </div>
                                    <div class="create-btn text-center">
                                        <p>
                                            Have an Account?
                                            <a href="<?php echo e(url('user-login')); ?>">
                                                Sign In
                                                <i class="bx bx-chevrons-right bx-fade-right"></i>
                                            </a>
                                        </p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-scripts'); ?>

<script>
    $(document).ready(function() {
        // alert('ok')
        $('#type').change(function() {
            if($(this).val()=='employee') {
                $('input[name=aadhar]').prop('required', true)
                $('input[name=aadhar_img]').prop('required', true)
                $('#emptype').show()
                $('#gp').prop('required', true)
            }else {
                $('#emptype').hide()
                $('#gp').prop('required', false)
                $('input[name=aadhar]').prop('required', false)
                $('input[name=aadhar_img]').prop('required', false)
            }
        })
        
        $('#gp').change(function() {
            if($(this).val()=='group') {
                $('#group-box').show()
                $('#gpname').prop('required', true)
                $('#gpphone').prop('required', true)
            }else {
                $('#group-box').hide()
                $('#gpname').prop('required', false)
                $('#gpphone').prop('required', false)
            }
        })
        
        $('#add-gp').click(function() {
            var total_length=$('.element').length;
            var lastid=$('.element:last').attr('id');
            var split_id=lastid.split('_');
            var nextindex=Number(split_id[1])+1;
            // alert(nextindex)
            var max=25;
            if(total_length<25) {
                $('.element:last').after('<div class="element" id="div_'+nextindex+'"></div>');
                $('#div_'+nextindex).append('<hr/>'
                                            +'<div class="form-group">'
                                            +'<label>Name</label>'
                                            +'<input type="text" class="form-control" name="gpname[]" id="gpname" required>'
                                            +'<label>Phone</label>'
                                            +'<input type="text" class="form-control" name="gpphone[]" id="gpphone" required>'
                                            +'<br/>'
                                            +'<button class="btn btn-danger remove" id="remove_'+nextindex+'">X</button>'
                                            +'</div>');
            }
        })
        
        $('.container').on('click', '.remove', function() {
            var id=this.id;
            var remove_id=id.split('_');
            $('#div_'+remove_id[1]).remove();
        })
    })
</script>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('mpn.front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rendement/public_html/mpn/manpower-app/resources/views/mpn/front/register.blade.php ENDPATH**/ ?>