
                <footer class="footer">
                    <?php echo e(date('Y')); ?> © Manpower Nation
                </footer>

            </div>
            <!-- End Right content here -->

        </div>
        <!-- END wrapper -->


        <!-- jQuery  -->
        <script src="<?php echo e(asset('ui/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/modernizr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/detect.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/fastclick.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/jquery.blockUI.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/waves.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/jquery.nicescroll.js')); ?>"></script>
        <script src="<?php echo e(asset('ui/js/jquery.scrollTo.min.js')); ?>"></script>

        <?php echo $__env->yieldContent('extra-scripts'); ?>

        <script src="<?php echo e(asset('ui/js/app.js')); ?>"></script>

        <?php echo $__env->yieldContent('add-scripts'); ?>

    </body>
</html><?php /**PATH D:\xampp\htdocs\manpower-app\resources\views/mpn/includes/footer.blade.php ENDPATH**/ ?>