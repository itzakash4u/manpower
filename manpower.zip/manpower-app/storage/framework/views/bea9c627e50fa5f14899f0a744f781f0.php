<?php $__env->startSection('content'); ?>

        <!-- Page Title Start -->
        <section class="page-title title-bg10">
            <div class="d-table">
                <div class="d-table-cell">
                    <h2>Account</h2>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>KYC</li>
                    </ul>
                </div>
            </div>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </section>
        <!-- Page Title End -->

        <!-- Account Area Start -->
        <?php if(Session::has('success')): ?> <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div> <?php endif; ?>
        <?php if(Session::has('danger')): ?> <div class="alert alert-danger"><?php echo e(Session::get('danger')); ?></div> <?php endif; ?>
        <section class="account-section ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <?php if($user->kyc_status=='pending'): ?>
                        <div class="alert alert-warning">Pending</div>
                        <?php elseif($user->kyc_status=='rejected'): ?>
                        <div class="alert alert-danger">Rejected</div>
                        <?php elseif($user->kyc_status=='approved'): ?>
                        <div class="alert alert-success">Approved</div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <!--<div class="col-md-4">-->
                    <!--    <div class="account-information">-->
                    <!--        <div class="profile-thumb">-->
                    <!--            <img src="assets/img/account.jpg" alt="account holder image">-->
                    <!--            <img src="<?php echo e(asset('media/profile/'.$user->profile_image)); ?>" alt="account holder image">-->
                    <!--            <h3><?php echo e($user->name); ?></h3>-->
                    <!--            <p>Web Developer</p>-->
                    <!--        </div>-->

                    <!--        <ul>-->
                    <!--            <li>-->
                    <!--                <a href="view-profile/<?php echo e($user->id); ?>" class="active">-->
                    <!--                    <i class='bx bx-user'></i>-->
                    <!--                    My Profile-->
                    <!--                </a>-->
                    <!--            </li>-->
                    <!--            <li>-->
                    <!--                <a href="resume.html" target="_blank">-->
                    <!--                    <i class='bx bxs-file-doc'></i>-->
                    <!--                    My Resume-->
                    <!--                </a>-->
                    <!--            </li>-->
                    <!--            <li>-->
                    <!--                <a href="#">-->
                    <!--                    <i class='bx bx-briefcase'></i>-->
                    <!--                    Applied Job-->
                    <!--                </a>-->
                    <!--            </li>-->
                    <!--        </ul>-->
                    <!--    </div>-->
                    <!--</div>-->

                    <div class="col-md-12">
                        <div class="account-details">
                            <h3>KYC</h3>
                            <form method="post" class="basic-info" action="<?php echo e(url('employee-update-kyc')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Aadhar Number</label>
                                            <input type="text" class="form-control" name="aadhar_no" value="<?php echo e($user->aadhar_no); ?>" required>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Aadhar Image</label>
                                            <input type="file" name="aadhar_img" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <a href="<?php echo e(asset('media/aadhar/'.Auth::user()->aadhar_image)); ?>" target="_blank"><img src="<?php echo e(asset('media/aadhar/'.Auth::user()->aadhar_image)); ?>" width="160" height="140"></a>
                                            <span></span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12" <?php if($user->kyc_status=='pending' || $user->kyc_status=='approved'): ?> style="display:none" <?php endif; ?>>
                                        <button type="submit" class="account-btn">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Account Area End -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-scripts'); ?>


<script>
    $(document).ready(function() {
        $('#repass').keyup(function(e) {
            if($('#pass').val()!=$('#repass').val()) {
                $('#submit').prop('disabled', true)
                $('#err').html('Password not matched!')
            }else {
                $('#submit').prop('disabled', false)
                $('#err').html('')
            }
        })
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('mpn.front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rendement/public_html/mpn/manpower-app/resources/views/mpn/front/kyc.blade.php ENDPATH**/ ?>