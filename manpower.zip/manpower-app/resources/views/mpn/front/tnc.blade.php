@extends('mpn.front.layout')

@section('content')

        <!-- Page Title Start -->
        <section class="page-title title-bg10">
            <div class="d-table">
                <div class="d-table-cell">
                    <h2>Account</h2>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>T&C</li>
                    </ul>
                </div>
            </div>
            <div class="lines">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
        </section>
        <!-- Page Title End -->

        <!-- Account Area Start -->
        @if(Session::has('success')) <div class="alert alert-success">{{Session::get('success')}}</div> @endif
        @if(Session::has('danger')) <div class="alert alert-danger">{{Session::get('danger')}}</div> @endif
        <section class="account-section ptb-100">
            <div class="container">

                <div class="row">


                    <div class="col-md-12">
                        <div class="account-details">
                            <h3>Terms & Conditions</h3>
1) Registration with Aadhar card. Phone number, then ‘Manpower nation’ will provide Unique ID 
card online.
2) Provide ‘Manpower nation’ with Bank details or UPI ID or registered phone number (G-Pay, 
.Phonepe, BHIM, Paytm) for the payment transaction.
3) The job post needs 50% of the total assignment payment at the beginning.
4) If the job provider/clientcancels the job after the employee is appointed, the Job provider
has 15mins to cancel the job to get the refund in 24 hours.
5) If the job provider/client tries to cancel the job after 15mins rule, the employees or the 
companyare not liable to complete the job and the company isn’t liable to refund the 
assignment any payment.
6) If the job provider/clientcancels consecutive or 4 jobs within a week or month then the 
company will be forced to ban them from the association.
7) The job provider/client consist of categories:-***
i. Business guru – A job provider/clientprovided over Rs- 15, 00,000/-of 
business in a year will receive a tourism and travelling aero plane tickets in 
India(up and down tickets of any 2 states for a week 2 times in that year) 
from the company and 15% of discount of each transition for a year,
ii. Marketing expert- A job provider/clientprovided over Rs-4, 00,000/-of 
business in a year will receive a business credibility letter from the 
company and 10% of discount of each transition.
iii. Self maker- Any startup business or self employed no assigned business. 
8) If the employee tries to cancel the job after accepting the job within 15mins, have to show 
good reasons to the company with proof then the employee can skip the job, but if the 
employee tries to cancel more than 2 jobs/assignments the employee will be suspended
from the company for 1 month.
9) The solo employee can accept 6 jobs max from a fixed sector assigned.
10) The group employee can accept any types of jobs or numerous jobs daily.
11) If the employee gets any legitimate complain of unprofessional and wrong behavior from a 
Job provider the employee gets banned for a week.
12) If any damage occurred with the assignment the employee will be liable company will notbe 
held accountable.
13) If the employee gets (5) legitimate complain of unprofessionalism and wrong behavior from 
a Job provider the employee gets banned from the company forever.
14) If the employee gets good review from his consecutive 10 assignments they will be rewarded 
10% extra bonus of the days earnings.
TERMS AND CONDITIONS
15) The employment consist of categories:-
I. Apex -completed 4500 assignment with 90% of good reviews- the will be at top 
Employees list yearly, 20% bonus for upcoming 1 year’s earnings.
II. Chief - completed 3000 assignment with 80% of good reviews- will be rewarded 
10% bonus for upcoming 1 year’s earnings.
III. Captain (A) completed 1500 assignment with 80% of good reviews- will be rewarded 
5% bonus for upcoming 1 year’s earnings.
IV. Basic 
16) If the job provider/clientor the employee breaks any law regarding Indian constitution then 
the company isn’t liabilities for it and the company (Manpower Nation) is not liable for any 
type of claims oranycompensations.
17) Any accusation if proven on job provider/client or employee will be take in consideration by 
the company and be resolved within one week under the companies guideline till then the 
assignment payment will be at hold.
18) Company isn’t liable to anyone’s personal issues either of job provider/client s or 
employees, if any of them the Job provider/client or employee get involved with anyillegal 
deed according to Indian Laws, the Company shall not be hold accountable to any 
responsibilities.
19) If either of job provider/client /clientor employee wants to file a complaint against each 
other they can do under Indian laws they hold the right as democratic nation the company 
will not Be involved,
20)The job provider/client or employee need to show identity prove when get in contact during 
any job or assignment, if any of the party fail to show or prove their identity the other party 
can ask for change the employee.
21) The employee receive a unique ID from company, captain and chief tire random weekly
incentives as the company post on fishing board & Apex tire the employee will receive a gold 
ID card + insurance + random incentives.
22) After the job provider/client reached 2nd level they receive an acknowledgement certificate 
form the company, and when reached 1st level chance to win a yearly lottery within the 
company each year.
23) Each year on the companies birthday eve the company will post annual notification that the 
job provider/client and the employees must read. And a surprise for a lucky person to 
receive a special gift on the companies birthday.
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Account Area End -->

@stop

@section('add-scripts')


<script>
    $(document).ready(function() {
        $('#repass').keyup(function(e) {
            if($('#pass').val()!=$('#repass').val()) {
                $('#submit').prop('disabled', true)
                $('#err').html('Password not matched!')
            }else {
                $('#submit').prop('disabled', false)
                $('#err').html('')
            }
        })
    })
</script>
@stop

