@extends('jnmh.main')

@section('my-part')
<p>Hello</p>
@stop

