<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use App\Models\Job;
use Illuminate\Support\Facades\Auth;
use App\Models\Jobapply;
use App\Models\Review;
use App\Models\Category;


class HomeController extends Controller
{
    //
    function index() {
        $jobs=Job::all();
        $cats=Category::all();
        return view('mpn.front.home-main', compact('jobs', 'cats'));
    }
    
    function job_search_result(Request $req) {
        if(!empty($req->title)) {
            $jobs=Job::where('title', 'LIKE', '%'.$req->title.'%')->get();
        }
        else if(!empty($req->location)) {
            $jobs=Job::where('location', 'LIKE', '%'.$req->location.'%')->get();
        }
        else if(!empty($req->category)) {
            $jobs=Job::where('cat_id', $req->category)->get();
        }
        return view('mpn.front.job-search-list', compact('jobs'));
    }
    
    function apply_job($jid, $uid) {
        $apply=new Jobapply;
        $apply->job_id=$jid;
        $apply->employee_id=$uid;
        $apply->save();
        Session::flash('success', 'Succesfully applied for job');
        return redirect('/');
    }

    function login() {
        return view('mpn.front.front-login');
    }
    function register() {
        $cats=Category::all();
        return view('mpn.front.register', compact('cats'));
    }

    function submit_register(Request $req) {
        $usr=new User;

        $req->validate([
            'aadhar'=>'required|unique:users,aadhar_no',
        ]);

        $usr->name=$req->name;
        $usr->category_id=$req->category;
        $usr->email=$req->email;
        $usr->phone=$req->phone;
        $usr->role=$req->type;
        if(!empty($req->gp)) {
            $usr->worker_type=$req->gp;
        }
        if(!empty($req->gpname)  && !empty($req->gpphone)) {
            $usr->group_member=json_encode(array('name'=>$req->gpname, 'phone'=>$req->gpphone));
        }
        if(!empty($req->aadhar)) {
            $usr->aadhar_no=$req->aadhar;
        }
        $usr->password=Hash::make($req->password);
        $usr->address=$req->addr;
        $usr->state=$req->state;
        if(!empty($req->file('profile_pic'))) {
            $file=$req->file('profile_pic');
            $fileName=time().$file->getClientOriginalName();
            $file->move(public_path('media/profile/'), $fileName);
            $usr->profile_image=$fileName;
        }
        if(!empty($req->file('aadhar_img'))) {
            $file2=$req->file('aadhar_img');
            $fileName2=time().$file2->getClientOriginalName();
            $file2->move(public_path('media/aadhar/'), $fileName2);
            $usr->aadhar_image=$fileName2;
        }
        $usr->ac_holder_name=$req->acc_holder;
        $usr->ac_number=$req->account_no;
        $usr->ifsc=$req->ifsc;
        $usr->kyc_status='pending';
        $usr->save();
        Session::flash('success', 'Data saved. Continue login...');
        return redirect('register-user');
        
    }

    function list_job() {
        $jobs=Job::where('user_id', Auth::id())->orderBy('id', 'desc')->paginate(10);
        return view('mpn.job', compact('jobs'));
    }

    function submit_job(Request $req) {
        $job=new Job;
        $job->cat_id=$req->cat;
        $job->user_id=Auth::user()->id;
        $job->job_id='MPNJ-'.Auth::user()->id.'-'.time();
        $job->title=$req->title;
        $job->company_name=$req->company;
        $job->description=$req->desp;
        $job->cost=$req->cost;
        $job->location=$req->location;
        $job->status=$req->status;
        $job->save();
        Session::flash('success', 'Data saved');
        return redirect('jobs');
    }

    function submit_edit_job(Request $req) {
        $job=Job::find($req->job_id);

        $job->cat_id=$req->cat;
        $job->title=$req->title;
        $job->company_name=$req->company;
        $job->description=$req->desp;
        $job->cost=$req->cost;
        $job->location=$req->location;
        $job->status=$req->status;
        $job->save();
        Session::flash('success', 'Data updated');
        return redirect('jobs');
    }

    function remove_job($id) {
        Job::where('id', $id)->delete();
        Session::flash('danger', 'Job deleted!');
        return redirect('jobs');
    }

    function job_review() {
        $data['reviews']=Review::where('client_id', Auth::id())->orderBy('id', 'desc')->paginate(10);
        return view('mpn.client.reviews', $data);
    }

    function show_review($job_id) {
        $data['job']=Job::find($job_id);
        $data['reviews']=Review::where('job_id', $job_id)->orderBy('id', 'desc')->paginate(10);
        return view('mpn.client.show-reviews', $data);
    }

    function job_apply() {
        $jobs=Job::where('user_id', Auth::id())->get();
        return view('mpn.client.job-apply', compact('jobs'));
    }

    //password change

    function change_password() {
        return view('mpn.change-password');
    }

    function submit_change_password() {
        $user=User::find(Auth::id());
        if(Hash::check($_POST['old'], $user->password)) {
            $user->password=Hash::make($_POST['password']);
            $user->save();
            if(Auth::user()->role=='employee') {
                Session::flash('success', 'Password changed');
                return redirect('employee-change-password');
            }
            Session::flash('success', 'Password changed');
            return redirect('change-password');
        }else {
            if(Auth::user()->role=='employee') {
                Session::flash('danger', 'Old password not matched!');
                return redirect('employee-change-password');
            }
            Session::flash('danger', 'Old password not matched!');
            return redirect('change-password');
        }
    }
    
    function change_pass_employee() {
        $user=Auth::user();
        return view('mpn.front.change-password', compact('user'));
    }


    //profile

    function profile() {
        $user=Auth::user();
        return view('mpn.profile', compact('user'));
    }

    function update_profile(Request $req) {
        $user=User::find(Auth::id());
        $dup_email=User::whereNotIn('id', [Auth::id()])->where('email', $req->email)->get();
        $dup_phone=User::whereNotIn('id', [Auth::id()])->where('phone', $req->phone)->get();
        $dup_acno=User::whereNotIn('id', [Auth::id()])->where('phone', $req->phone)->get();
        if(count($dup_email)>0 || count($dup_phone)>0 || count($dup_acno)>0) {
            Session::flash('danger', 'Duplicate entry not allowed!');
            return redirect('profile');
        }else {
            $user->name=$req->name;
            $user->email=$req->email;
            $user->phone=$req->phone;
            $user->address=$req->address;
            $user->state=$req->state;
            $user->ac_holder_name=$req->acc_holder;
            $user->ac_number=$req->ac_no;
            $user->ifsc=$req->ifsc;
            if(!empty($req->file('pic'))) {
                $file=$req->file('pic');
                $fileName=time().$file->getClientOriginalName();
                $file->move(public_path('media/profile/'), $fileName);
                $user->profile_image=$fileName;
            }
            $user->save();
            Session::flash('success', 'Data updated');
            return redirect('profile');
        }
    }

    //kyc

    function kyc_details() {
        $user=Auth::user();
        return view('mpn.kyc', compact('user'));
    }


    //customer care

    function care_job_confirmation() {
        $applies=Jobapply::where('cc_approved', 0)->orderBy('id', 'desc')->paginate(10);
        return view('mpn.care.confirm-job', compact('applies'));
    }

    function care_confirm_job($id) {
        $apply=Jobapply::find($id);
        $apply->cc_approved=1;
        $apply->save();
        Session::flash('success', 'Job confirmed');
        return redirect('care-job-apply');
    }
    
    
    //profile
    
    function view_profile($id) {
        $cats=Category::all();
        $user=User::find($id);
        return view('mpn.front.profile', compact('user', 'cats'));
    }
    
    function update_employee_profile(Request $req) {
        $user=User::find($req->eid);
        $user->name=$req->name;
        $user->email=$req->email;
        $user->phone=$req->phone;
        $user->address=$req->address;
        $user->worker_type=$req->work_type;
        $user->category_id=$req->category;
        $user->ac_holder_name=$req->acc_holder;
        $user->ac_number=$req->ac_number;
        $user->ifsc=$req->ifsc;
        $user->group_member=json_encode(array('name'=>$req->gpname, 'phone'=>$req->gpphone));
        if(!empty($req->file('pic'))) {
            $file=$req->file('pic');
            $fileName=time().$file->getClientOriginalName();
            $file->move(public_path('media/profile/'), $fileName);
            $user->profile_image=$fileName;
        }
        $user->save();
        Session::flash('success', 'Profile updated');
        return redirect('view-profile/'.$req->eid);
    }
    
    function employee_id_card() {
        $user=Auth::user();
        return view('mpn.front.id-card', compact('user'));
    }
    
    function employee_applied_job() {
        $applied=Jobapply::where('employee_id', Auth::id())->get();
        return view('mpn.front.applied-job', compact('applied'));
    }
    
    function about() {
        return view('mpn.front.about');
    }
    
    function contact() {
        return view('mpn.front.contact');
    }
    
    function view_job_details($id) {
        $job=Job::find($id);
        return view('mpn.front.job-details', compact('job'));
    }
    
    function employee_kyc() {
        $user=User::find(Auth::id());
        return view('mpn.front.kyc', compact('user'));
    }
    
    function employee_update_kyc(Request $req) {
        $user=User::find(Auth::id());
        $user->aadhar_no=$req->aadhar_no;
        if(!empty($req->file('aadhar_img'))) {
            $file=$req->file('aadhar_img');
            $filename=time().$file->getClientOriginalName();
            $file->move(public_path('media/aadhar/'), $filename);
            $user->aadhar_image=$filename;
        }
        $user->kyc_status='pending';
        $user->save();
        Session::flash('success', 'Kyc updated');
        return redirect('employee-kyc');
    }
    
    function term_cond() {
        return view('mpn.front.tnc');
    }



}

?>