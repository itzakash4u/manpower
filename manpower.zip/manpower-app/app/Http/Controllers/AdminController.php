<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User;

use App\Models\Category;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use App\Models\Job;
use App\Models\Jobapply;
use Illuminate\Support\Facades\Hash;
use App\Models\Commission;


class AdminController extends Controller
{
    //
    public function login() {
        return view('mpn.login');
    }

    function list_category() {
        $cats=Category::orderBy('id', 'desc')->paginate(10);
        return view('mpn.add-category', compact('cats'));
    }

    function submit_category(Request $req) {
        $cat=new Category;
        $req->validate([
            'category'=> 'required',
        ]);
        $cat->category_name=$req->category;
        $cat->save();
        Session::flash('success', 'Category created.');
        return redirect('category');
    }

    function submit_edit_category(Request $req) {
        $cat=Category::find($req->cat_id);
        $cat->category_name=$req->category;
        $cat->save();
        Session::flash('success', 'Category updated.');
        return redirect('category');
    }

    function remove_category($id) {
        Category::where('id', $id)->delete();
        Session::flash('danger', 'Category deleted!');
        return redirect('category');
    }

    function list_employer() {
        $employers=User::where('role', 'employer')->orderBy('id', 'desc')->paginate(10);
        return view('mpn.admin.list-employer', compact('employers'));
    }

    function remove_employer($id) {
        User::where('id', $id)->delete();
        Session::flash('danger', 'Deleted!');
        return redirect('employer');
    }

    function list_employee() {
        $employees=User::where('role', 'employee')->orderBy('id', 'desc')->paginate(10);
        return view('mpn.admin.employee', compact('employees'));
    }

    function remove_employe($id) {
        User::where('id', $id)->delete();
        Session::flash('danger', 'Deleted!');
        return redirect('employee');
    }

    function all_jobs() {
        $jobs=Job::orderBy('id', 'desc')->paginate(10);
        return view('mpn.admin.all-jobs', compact('jobs'));
    }

    function edit_job(Request $req) {
        $job=Job::find($req->job_id);

        $job->cat_id=$req->cat;
        $job->title=$req->title;
        $job->company_name=$req->company;
        $job->description=$req->desp;
        $job->cost=$req->cost;
        $job->location=$req->location;
        $job->status=$req->status;
        $job->save();
        Session::flash('success', 'Data updated');
        return redirect('all-jobs');
    }
    
    function remove_job($id) {
        Job::where('id', $id)->delete();
        Session::flash('danger', 'Job deleted!');
        return redirect('all-jobs');
    }

    function job_apply() {
        $applies=Jobapply::orderBy('id', 'desc')->paginate(10);
        return view('mpn.admin.all-job-apply', compact('applies'));
    }

    function care_agent() {
        $agents=User::where('role', 'care')->orderBy('id', 'desc')->paginate(10);
        return view('mpn.admin.customer-care', compact('agents'));
    }

    function register_agent(Request $req) {
        $usr=new User;

        $req->validate([
            'aadhar'=>'required|unique:users,aadhar_no',
            'ac_no'=>'required|unique:users,ac_number',
        ]);

        $usr->name=$req->name;
        $usr->email=$req->email;
        $usr->phone=$req->phone;
        $usr->role='care';
        $usr->aadhar_no=$req->aadhar;
        $usr->password=Hash::make($req->password);
        $usr->address=$req->addr;
        $usr->state=$req->state;
        if(!empty($req->file('profile_pic'))) {
            $file=$req->file('profile_pic');
            $fileName=time().$file->getClientOriginalName();
            $file->move(public_path('media/profile/'), $fileName);
            $usr->profile_image=$fileName;
        }
        if(!empty($req->file('aadhar_img'))) {
            $file2=$req->file('aadhar_img');
            $fileName2=time().$file2->getClientOriginalName();
            $file2->move(public_path('media/aadhar/'), $fileName2);
            $usr->aadhar_image=$fileName2;
        }
        $usr->ac_holder_name=$req->acc_holder;
        $usr->ac_number=$req->account_no;
        $usr->ifsc=$req->ifsc;
        $usr->save();
        Session::flash('success', 'Data saved.');
        return redirect('customer-care');
    }

    function update_agent(Request $req) {
        $user=User::find($req->care_id);
        $dup_email=User::whereNotIn('id', [$req->care_id])->where('email', $req->email)->get();
        $dup_phone=User::whereNotIn('id', [$req->care_id])->where('phone', $req->phone)->get();
        $dup_acno=User::whereNotIn('id', [$req->care_id])->where('ac_number', $req->ac_no)->get();
        if(count($dup_email)>0 || count($dup_phone)>0 || count($dup_acno)>0) {
            Session::flash('danger', 'Duplicate entry not allowed!');
            return redirect('customer-care');
        }else {
            $user->name=$req->name;
            $user->email=$req->email;
            $user->phone=$req->phone;
            $user->address=$req->address;
            $user->state=$req->state;
            $user->ac_holder_name=$req->acc_holder;
            $user->ac_number=$req->ac_no;
            $user->ifsc=$req->ifsc;
            if(!empty($req->file('pic'))) {
                $file=$req->file('pic');
                $fileName=time().$file->getClientOriginalName();
                $file->move(public_path('media/profile/'), $fileName);
                $user->profile_image=$fileName;
            }
            $user->save();
            Session::flash('success', 'Data updated');
            return redirect('customer-care');
        }
    }

    function delete_agent($id) {
        User::where('role', 'care')->where('id', $id)->delete();
        Session::flash('danger', 'Agent deleted');
        return redirect('customer-care');
    }

    function charges() {
        $charge=Commission::find(1);
        return view('mpn.admin.commission', compact('charge'));
        // return $charge->charges;
    }

    function edit_charges() {
        $charge=Commission::find(1);

        $charge->charges=$_POST['commission'];
        $charge->save();
        Session::flash('success', 'Commission updated');
        return redirect('charges');
    }

    function check_kyc() {
        $users=User::where('role', ['employee'])->where('kyc_status', 'pending')->orderBy('id', 'desc')->paginate(10);
        return view('mpn.admin.check-kyc', compact('users'));
    }

    function approve_kyc($id) {
        $user=User::find($id);
        $user->kyc_status='approved';
        $user->save();
        Session::flash('success', 'Kyc Approved');
        return redirect('verify-kyc');
    }
    
    function reject_kyc($id) {
        $user=User::find($id);
        $user->kyc_status='rejected';
        $user->save();
        Session::flash('danger', 'Kyc rejected!');
        return redirect('verify-kyc');
    }



}
